import{_ as o}from"./MenubarContent.vue_vue_type_script_setup_true_lang-2fac093b.js";import"./index-06614974.js";import"./app-f6dff7c1.js";import"./utils-836e31d3.js";export{o as default};
