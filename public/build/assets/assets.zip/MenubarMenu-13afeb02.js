import{_ as o}from"./MenubarMenu.vue_vue_type_script_setup_true_lang-00969a40.js";import"./index-06614974.js";import"./app-f6dff7c1.js";export{o as default};
