import{G as u,f as d}from"./index-06614974.js";import{c as f}from"./utils-836e31d3.js";import{c as m}from"./createLucideIcon-d2dc0d91.js";import{D as p,o as x,f as y,g as a,j as o,u as e,J as b,M as g}from"./app-f6dff7c1.js";/**
 * @license lucide-vue-next v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=m("CircleIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]),v=p({__name:"MenubarRadioItem",props:{value:{},disabled:{type:Boolean},textValue:{},asChild:{type:Boolean},as:{},class:{}},emits:["select"],setup(c,{emit:r}){const t=c,l=r;return(n,s)=>(x(),y(e(d),g(t,{class:[e(f)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",t.class)],onSelect:s[0]||(s[0]=i=>l("select",i))}),{default:a(()=>[o(e(u),{class:"absolute left-2 flex h-3.5 w-3.5 items-center justify-center"},{default:a(()=>[o(e(h),{class:"h-2 w-2 fill-curren"})]),_:1}),b(n.$slots,"default")]),_:3},16,["class"]))}});export{v as default};
