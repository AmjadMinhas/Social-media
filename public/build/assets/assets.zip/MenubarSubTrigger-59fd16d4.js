import{Q as s}from"./index-06614974.js";import{c as n}from"./utils-836e31d3.js";import{c as r}from"./createLucideIcon-d2dc0d91.js";import{D as c,o as l,f as p,g as u,J as d,j as m,u as e,M as f}from"./app-f6dff7c1.js";/**
 * @license lucide-vue-next v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=r("ChevronRightIcon",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]),B=c({__name:"MenubarSubTrigger",props:{disabled:{type:Boolean},textValue:{},asChild:{type:Boolean},as:{},inset:{type:Boolean},class:{}},setup(a){const t=a;return(o,h)=>(l(),p(e(s),f(t,{class:[e(n)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",o.inset&&"pl-8",t.class)]}),{default:u(()=>[d(o.$slots,"default"),m(e(i),{class:"ml-auto h-4 w-4"})]),_:3},16,["class"]))}});export{B as default};
