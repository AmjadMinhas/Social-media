import{_ as o}from"./Tabs.vue_vue_type_script_setup_true_lang-7e0e28ca.js";import"./index-06614974.js";import"./app-f6dff7c1.js";export{o as default};
